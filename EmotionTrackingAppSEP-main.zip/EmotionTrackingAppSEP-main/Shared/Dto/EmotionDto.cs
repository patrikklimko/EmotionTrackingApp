namespace DTO;

public class EmotionDto
{
  public required string Emotion { get; set; }
  public required string Color { get; set; }
  public required string Description { get; set; }
}