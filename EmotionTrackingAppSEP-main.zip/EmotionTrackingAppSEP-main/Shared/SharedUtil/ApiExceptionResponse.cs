namespace SharedUtil;

public class ApiExceptionResponse
{
  public required string Error { get; set; }
  public required string Type { get; set; }
  public required string Trace { get; set; }
}