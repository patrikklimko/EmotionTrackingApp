namespace DTO;

public class ReactionDeleteDto
{
  public int EmotionCheckInId { get; set; }
}