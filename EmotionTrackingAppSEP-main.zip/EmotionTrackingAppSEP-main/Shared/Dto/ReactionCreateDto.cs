namespace DTO;

public class ReactionCreateDto
{
  public string? Emoji { get; set; }
  public int EmotionCheckInId { get; set; }
}