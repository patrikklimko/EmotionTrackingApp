package dk.via.JavaDAO.Models;

public enum Color {
  BLUE, GREEN, YELLOW, RED
}
