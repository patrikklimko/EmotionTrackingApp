package dk.via.JavaDAO.Models;

public enum TagType {
  WHAT,
  WITH,
  WHERE
}
